import os

"""
home+ip+port+size+time
highlow+ip+port+time
icmp+ip+port+time
http+url+threads+time

home
poor 333
rich 3333
admin 33333
owner 55555

threads
poor 10
rich 25
admin 50
owner 200

time
poor 60
rich 240
admin 360
owner 500

"""

size_limits = {1: 55555, 2: 33333, 3: 3333, 4: 333}
time_limits = {1: 500, 2: 360, 3: 240, 4: 60}
thread_limits = {1: 200, 2: 50, 3: 25, 4: 10}

def handle_methods(cmd, args, user):

    # arg checks

    if len(args) > 4:
        return "invalid arguments (too much arguments)}"

    if int(args[1]) >= 65535 or int(args[1]) <= 0:
        return "invalid arguments"

    if cmd == "home" and size_limits[user[3]] < int(args[2]):
        return f"You have a size limit of {size_limits[user[3]]}"
        
    if time_limits[user[3]] < int(args[-1]):
        return f"You have a time limit of {time_limits[user[3]]}"
    
    if cmd == "http" and thread_limits[user[3]] < int(args[2]):
        return f"You have a thread limit of {thread_limits[user[3]]}"

    command = f"perl requester.pl {cmd}"

    for arg in args:
        command += f"+{arg}"

    os.system(command)

    return f"cmd: {cmd}, args: {args}"
