import socket

def tcp_ping(host, port, timeout=1):
    try:
        with socket.create_connection((host, port), timeout):
            return True
    except socket.error:
        return False

def read_hosts(file_path):
    hosts = []
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line:
                parts = line.split(':')
                if len(parts) == 2:
                    host = parts[0]
                    port = int(parts[1].split('/')[0])
                    hosts.append((host, port))
    return hosts

def write_hosts(file_path, hosts):
    with open(file_path, 'w') as file:
        for host, port in hosts:
            file.write(f"{host}:{port}/c?\n")

def main():
    file_path = 'host.txt'
    hosts = read_hosts(file_path)
    valid_hosts = []
    invalid_hosts = []

    for host, port in hosts:
        if tcp_ping(host, port):
            valid_hosts.append((host, port))
        else:
            invalid_hosts.append((host, port))

    write_hosts(file_path, valid_hosts)

    for host, port in valid_hosts:
        print(f"alive {host}:{port}")
    for host, port in invalid_hosts:
        print(f"dead {host}:{port}")

if __name__ == "__main__":
    main()