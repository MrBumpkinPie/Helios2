import socketserver
import sqlite3
import method_handles

"""
rank id 1: owner
rank id 2: admin
rank id 3: rich
rank id 4: poor
"""

welcome_message = """

                               ╦ ╦┌─┐┬  ┬┌─┐┌─┐┌─┐
                               ╠═╣├┤ │  ││ │└─┐│ │
                               ╩ ╩└─┘┴─┘┴└─┘└─┘└─┘                 
                      ══╦══════════════════════════════╦══
                 ╔══════╩══════════════════════════════╩══════╗
                 ║             Welcome To Helioso             ║
                 ║ - - -    Made By Helios DEV team     - - - ║
               ╔═╩════════════════════════════════════════════╩═╗
              ╔╩════════════════════════════════════════════════╩╗
              ║ - Type [help] to see all of Helioso's Commands - ║
              ╚══════════════════════════════════════════════════╝


"""

class EchoRequestHandler(socketserver.BaseRequestHandler):
    
    def __init__(self, request, client_address, server):
        self.user = None
        super().__init__(request, client_address, server)

    def handle(self):
        try:
            self.request.sendall(b"Enter username: ")
            username = self.request.recv(1024).strip().decode('utf-8')

            self.request.sendall(b"Enter password: ")
            password = self.request.recv(1024).strip().decode('utf-8')

            if self.validate_credentials(username, password):
                self.username = username
                self.request.sendall(b"Login successful!\n")
                self.send_welcome_message()
                self.request.sendall(b"=====>  ")
                self.interact()
            else:
                self.request.sendall(b"Invalid credentials. Connection closed.\n")
        except Exception as e:
            print(f"Error: {e}")
        finally:
            print("Connection closed.")

    def validate_credentials(self, username, password):
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute('''
        SELECT * FROM users WHERE username = ? AND password = ?
        ''', (username, password))
        user = cursor.fetchone()
        conn.close()
        self.user = user
        return user is not None

    def send_welcome_message(self):
        self.request.sendall(welcome_message.encode('utf-8'))
        self.request.sendall(b'\n=====>  ')
        self.request.flush()

    def interact(self):
        while True:
            try:
                data = self.request.recv(1024).strip()
                if not data:
                    break
                message = data.decode('utf-8')
                print(f"Received: {message}")

                response = self.handle_message(message)
                self.request.sendall(response.encode('utf-8'))
                self.request.sendall(b'\n=====>  ')
                self.request.flush()
            except Exception as e:
                print(f"Error: {e}")
                break

    def handle_message(self, message):
        parts = message.split()
        cmd = parts[0].lower()
        args = parts[1:]

        if cmd == 'help':
            return self.handle_help()
        elif cmd == 'admin':
            return self.handle_admin()
        elif cmd == 'methods':
            return self.handle_methods()
        elif cmd in ['home', 'highlow', 'icmp', 'http']:
            return method_handles.handle_methods(cmd, args, self.user)
        else:
            return 'Command does not exist\n'

    def handle_methods(self):
        return """\033

                            ┌┬┐┌─┐┌┬┐┬ ┬┌─┐┌┬┐┌─┐  
                            │││├┤  │ ├─┤│ │ ││└─┐  
                            ┴ ┴└─┘ ┴ ┴ ┴└─┘─┴┘└─┘  
    ╔════════════════╗╔════════════════╗╔════════════════╗╔════════════════╗
    ║ ICMP           ║║ HOME           ║║ Highlow        ║║ HTTP           ║
    ╚════════════════╝╚════════════════╝╚════════════════╝╚════════════════╝

        \033[0m"""

    def handle_help(self):
        return """
                                    ╦ ╦┌─┐┬  ┌─┐
                                    ╠═╣├┤ │  ├─┘
                                    ╩ ╩└─┘┴─┘┴  
                          ═╦═══════════════════════════╦═
               ╔═══════════╩═╦═════════════════════════╩═══════════╗
               ║ Methods     ║ Shows Methods For Helioso.          ║
               ║ Admin       ║ Shows Helioso's ADMIN.              ║
               ╚═════════════╩═════════════════════════════════════╝

        """

    def handle_admin(self):
        if self.user[3] not in (1, 2):
            return "Command does not exist"
        else:
            return "admin commands are not ready yet"


if __name__ == "__main__":
    HOST, PORT = "0.0.0.0", 65001

    with socketserver.TCPServer((HOST, PORT), EchoRequestHandler) as server:
        print(f"Server started at {HOST}:{PORT}")
        server.serve_forever()
