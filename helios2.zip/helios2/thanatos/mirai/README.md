# Mirai Iot BotNet by 0Days

#### What is Mirai Iot ?

read a litle about here:

http://dyn.com/blog/dyn-statement-on-10212016-ddos-attack/

#

Leaked Linux.Mirai Source Code for Research/IoT Development Purposes

Uploaded for research purposes and so we can develop IoT and such.

See "ForumPost.txt" or [ForumPost.md](ForumPost.md) for the post in which it
leaks, if you want to know how it is all set up and the likes.

## Requirements
* gcc
* golang
* electric-fence
* mysql-server
* mysql-client

#### Requirements install in your windows :

 * Winscp
 * Putty
 
 or
 
 * MobaXterm & Putty
 
for links use google.com

!!!!! USE THE OFFICIAL WEBSITE NO OTHERS !!!!!

 
 System MINIMUM Requirements:
 

OS:
* Debian 86x_64x

RAM: 

* 8GB / 10GB

Internet Speed:

Down

* 800Mb/s

Up

* 200Mb/s

CPU:

* Xeon

HDD:

* 120GB 
 
##### Suggestion VPS:

* https://www.nforce.com/                                      
                                                            
* http://www.novogara.com/                                      

* https://www.dataclub.biz/ (Accepts Everything but Paypal.)   

* https://www.bhost.net 
 
 ** Google for more vps server's (AWS,AZURE, GoogleComputer engine, etc...)
 
 
## SETUP TUTORIAL 
you can find the TUTORIAL in this github project:

https://github.com/Screamfox/0x2423config/blob/master/TUTORIAL.txt


** !!!!! FOR EDUCATIONAL PURPOSES ONLY !!!!!!!! **

**AND NOT FOR DDOS ATTACKS**

## Credits
[Anna-senpai](https://hackforums.net/showthread.php?tid=5420472)

## Disclaimer
This repository is for academic purposes, the use of this software is your
responsibility.

## Warning
The [zip file](https://www.virustotal.com/en/file/f10667215040e87dae62dd48a5405b3b1b0fe7dbbfbf790d5300f3cd54893333/analysis/1477822491/) for the is repo is being identified by some AV programs as malware.  Please take caution. 





## Looking for more Botnets for ddos attacks and spam ? this is the list the botnet i know !!

* spyeye,
* zeus,
* citadel,
* ice 9,
* Ufonet, (IS A CANCER)!!
* Atmos,
* DENDROID,
* Grum
* ZeroAccess
* Windigo
* Storm
* Cutwail
* Conficker
* Srizbi
* Kraken
* Metulji and Mariposa
* µBOT originally named “WEBNET”
* festi botnet
* carna botnet
* Srizbi botnet


#### *Sincerely , Screamfox AB member
