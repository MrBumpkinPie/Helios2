use strict;
use warnings;
use IO::Socket::INET;
use threads;
if (@ARGV != 1) {
    die "Usage: perl requester.pl <command>\n";
}
my $command = $ARGV[0];
open(my $fh, '<', 'host.txt') or die "FAILED 'host.txt' $!";
my @servers;
while (my $line = <$fh>) {
    chomp $line;
    $line =~ s/\r//g; 
    push @servers, $line;
}
close($fh);
sub send_raw_http_request {
    my ($host, $port, $path) = @_;
    my $socket = IO::Socket::INET->new(
        PeerAddr => $host,
        PeerPort => $port,
        Proto    => 'tcp'
    ) or die "FAILED $host:$port: $!"; 
    print $socket "GET $path HTTP/1.1\r\n";
    print $socket "Host: $host\r\n";
    print $socket "Connection: close\r\n";
    print $socket "\r\n";
    while (my $line = <$socket>) {

    }
    close($socket);
}
my @threads;
foreach my $server (@servers) {
    if ($server =~ m{^(.*?):(\d+)(/.*)$}) {
        my ($host, $port, $path) = ($1, $2, $3 . $command);
        push @threads, threads->create(\&send_raw_http_request, $host, $port, $path);
    } else {
        warn "Format Error: $server\n";
    }
}

$_->join() for @threads;
