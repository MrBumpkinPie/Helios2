def read_ips(file_path):
    ips = []
    with open(file_path, 'r') as file:
        for line in file:
            ip = line.strip()
            if ip:
                ips.append(ip)
    return ips

def write_hosts(file_path, ips, port=65004):
    with open(file_path, 'w') as file:
        for ip in ips:
            file.write(f"{ip}:{port}/c?\n")

def main():
    input_file = 'yoinked.txt'
    output_file = 'host.txt'

    ips = read_ips(input_file)
    write_hosts(output_file, ips)

if __name__ == "__main__":
    main()
