import sqlite3

def create_database():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        rank INTEGER
    )
    ''')

    cursor.execute('''
    INSERT OR IGNORE INTO users (username, password, rank)
    VALUES (?, ?, ?)
    ''', ('admin', 'password', 1))

    cursor.execute('''
    INSERT OR IGNORE INTO users (username, password, rank)
    VALUES (?, ?, ?)
    ''', ('test', 'testpass', 4))



    conn.commit()
    conn.close()
    print("Database created and test user added.")

if __name__ == "__main__":
    create_database()

